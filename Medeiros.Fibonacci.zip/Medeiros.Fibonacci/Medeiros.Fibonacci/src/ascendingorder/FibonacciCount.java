package ascendingorder;

import javax.swing.JOptionPane;

public class FibonacciCount {

	int count;
	int x = 0;
	int y = 1;

	{
		JOptionPane.showMessageDialog(null, "0");
		JOptionPane.showMessageDialog(null, "1");
		for (int n = 0; n < 20; n++) {
			int sum = Math.abs(x) + y;
			JOptionPane.showMessageDialog(null,sum);
			x = sum;
			int sum2 = Math.abs(x) + y;
			JOptionPane.showMessageDialog(null,sum2);
			y = sum2;
			int sum3 = Math.abs(x) + y;
			JOptionPane.showMessageDialog(null,sum3);
		}
	}
}

//Set the program up already knowing the first 2 digits of the sequence. 
//Have the program add up those two numbers to get the next number in the sequence 
//Have the program take the new number and replace the first number with it
//Repeat until it has the first 50 numbers of the sequence.


//Stubs
//Set one value to 0
//Set another value to 1
//Create a loop that adds the two values repeats as many times as desired in order to reach the wanted amount of numbers
//Add the two numbers
//Replace the first value with the sum of the operation
//Add again
//Replace the second value with the sum of the operation
//Add again
//Repeat until loop finishes
